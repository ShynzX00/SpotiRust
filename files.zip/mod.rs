// src/cef/mod.rs
//
// CEF lifecycle:
//   1. `CefSettings` – persistent cache/cookies, Widevine CDM path.
//   2. `AppHandler`  – top-level CEF application callbacks.
//   3. `BrowserHandler` – per-browser callbacks (frame load, IPC messages).
//
// The JS bridge is injected via OnLoadEnd for frames whose URL matches
// open.spotify.com.  Incoming messages are dispatched through souvlaki's
// `CommandSink` abstraction so this module stays UI-agnostic.

use std::{path::PathBuf, sync::Arc};
use parking_lot::Mutex;
use tracing::{info, warn, error};

use crate::{
    ipc::{InboundMessage, JsCommand},
    player::{SharedState, CommandSink},
    widevine::widevine_cdm_path,
};

// ── Bridge JS source ──────────────────────────────────────────────────────────

/// The bridge script is embedded at compile time from `assets/bridge.js`.
const BRIDGE_JS: &str = include_str!("../../assets/bridge.js");

// ── Settings helpers ──────────────────────────────────────────────────────────

/// Returns the user-data directory for CEF (persistent cookies + cache).
pub fn user_data_path() -> PathBuf {
    dirs::data_local_dir()
        .unwrap_or_else(|| PathBuf::from("."))
        .join("spoti-rust")
        .join("cef-profile")
}

/// Build the platform-specific `CefSettings` struct.
///
/// NOTE: `cef::CefSettings` fields shown here are illustrative; map them to
/// the actual cef-rs API once you pin the crate version.
pub fn build_cef_settings() -> cef::CefSettings {
    let mut settings = cef::CefSettings::default();

    // Persistent profile – login sessions survive restarts.
    let profile = user_data_path();
    std::fs::create_dir_all(&profile).ok();
    settings.root_cache_path   = profile.to_str().unwrap_or("").into();
    settings.cache_path        = profile.join("cache").to_str().unwrap_or("").into();

    // Widevine – path resolved per-platform in `src/widevine.rs`.
    if let Some(wv) = widevine_cdm_path() {
        info!("Widevine CDM: {}", wv.display());
        settings.widevine_cdm_path = wv.to_str().unwrap_or("").into();
    } else {
        warn!("Widevine CDM not found – DRM content will not play");
    }

    // Chromium flags useful for Spotify PWA behaviour.
    settings.no_sandbox              = true;      // easier cross-platform setup
    settings.remote_debugging_port   = 9222;      // `chrome://inspect` during dev
    settings.log_severity            = cef::LogSeverity::Warning;

    settings
}

// ── App handler ───────────────────────────────────────────────────────────────

pub struct SpotiApp;

impl cef::App for SpotiApp {
    fn on_before_command_line_processing(
        &self,
        _process_type: &str,
        command_line: &mut cef::CommandLine,
    ) {
        // Enable proprietary codecs (AAC, MP3) required by Spotify.
        command_line.append_switch("enable-proprietary-codecs");
        // Allow autoplay so the web player starts without a user gesture.
        command_line.append_switch_with_value("autoplay-policy", "no-user-gesture-required");
        // Platform-specific GPU flags.
        #[cfg(target_os = "linux")]
        {
            command_line.append_switch("enable-gpu-rasterization");
            command_line.append_switch("use-gl");
            command_line.append_switch_with_value("use-gl", "desktop");
        }
        #[cfg(target_os = "macos")]
        {
            command_line.append_switch("enable-features=MetalANGLE");
        }
    }
}

// ── Browser / frame handler ───────────────────────────────────────────────────

pub struct BrowserHandler {
    state:        SharedState,
    command_sink: Arc<dyn CommandSink>,
}

impl BrowserHandler {
    pub fn new(state: SharedState, command_sink: Arc<dyn CommandSink>) -> Self {
        Self { state, command_sink }
    }
}

impl cef::client::Client for BrowserHandler {
    // ── Load handler: inject bridge.js on Spotify frames ─────────────────────

    fn on_load_end(
        &self,
        _browser: &cef::Browser,
        frame:    &cef::Frame,
        _status:  i32,
    ) {
        let url = frame.get_url();
        if url.contains("open.spotify.com") && frame.is_main() {
            info!("Injecting bridge.js into {url}");
            frame.execute_java_script(BRIDGE_JS, url.clone(), 0);
        }
    }

    // ── Message handler: JS → Rust IPC ───────────────────────────────────────

    fn on_process_message_received(
        &self,
        _browser: &cef::Browser,
        _frame:   &cef::Frame,
        _source:  cef::ProcessId,
        message:  &cef::ProcessMessage,
    ) -> bool {
        // The bridge sends a single-argument message whose value is JSON.
        let Some(json) = message.get_argument_list().get_string(0) else {
            return false;
        };

        match serde_json::from_str::<InboundMessage>(&json) {
            Ok(InboundMessage::StateUpdate(update)) => {
                let mut state = self.state.lock();
                state.current = Some(update.clone());
                // TODO: UI window hook – notify the frontend of new state.
                drop(state);
                // Propagate to OS media controls via souvlaki (see controls mod).
            }
            Ok(InboundMessage::PlayerReady(ready)) => {
                info!("PlayerReady: authenticated={}", ready.authenticated);
                self.state.lock().authenticated = ready.authenticated;
            }
            Err(e) => {
                error!("IPC parse error: {e}  raw={json}");
            }
        }

        true // message consumed
    }
}

// ── Command execution ─────────────────────────────────────────────────────────

/// Evaluate a `JsCommand` inside the main Spotify frame.
///
/// Call this from the controls module or UI button handlers.
pub fn exec_command(browser: &cef::Browser, cmd: JsCommand) {
    if let Some(frame) = browser.get_main_frame() {
        let js = cmd.to_js();
        frame.execute_java_script(js.clone(), "spoti-rust://command".into(), 0);
        info!("→ JS: {js}");
    }
}

// ── Browser creation ──────────────────────────────────────────────────────────

/// Create the hidden CEF browser window that runs open.spotify.com.
///
/// Returns the `Browser` handle so other modules can call `exec_command`.
pub fn create_browser(handler: BrowserHandler) -> cef::Browser {
    let mut window_info = cef::WindowInfo::default();
    // Hidden window – audio plays without a visible CEF chrome.
    window_info.window_name = "spoti-rust-hidden".into();
    window_info.style = cef::WindowStyle::Hidden;

    let browser_settings = cef::BrowserSettings::default();

    cef::browser_host::create_browser_sync(
        &window_info,
        Arc::new(handler),
        "https://open.spotify.com",
        &browser_settings,
        None,
        None,
    )
}
