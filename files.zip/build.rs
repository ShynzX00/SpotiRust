// build.rs
//
// Responsibilities
// ─────────────────
// 1. Locate the CEF binary distribution via $CEF_ROOT.
// 2. Emit linker flags so the executable finds libcef at runtime.
// 3. Locate the Widevine CDM library for the current platform and
//    emit its path as a compile-time env-var so main.rs can embed it.
//
// Run:  CEF_ROOT=/path/to/cef cargo build --release

use std::{env, path::PathBuf};

fn main() {
    let cef_root = env::var("CEF_ROOT")
        .map(PathBuf::from)
        .unwrap_or_else(|_| {
            // Fallback: look for a `cef/` subdirectory next to the crate root.
            PathBuf::from(env::var("CARGO_MANIFEST_DIR").unwrap()).join("cef")
        });

    // ── Link CEF ─────────────────────────────────────────────────────────────
    #[cfg(target_os = "linux")]
    {
        let lib_dir = cef_root.join("Release");
        println!("cargo:rustc-link-search=native={}", lib_dir.display());
        println!("cargo:rustc-link-lib=dylib=cef");
        // Embed the rpath so the binary finds libcef.so.1 at runtime.
        println!(
            "cargo:rustc-link-arg=-Wl,-rpath,$ORIGIN/lib:{}",
            lib_dir.display()
        );
    }

    #[cfg(target_os = "macos")]
    {
        let framework_dir = cef_root.join("Release");
        println!(
            "cargo:rustc-link-arg=-Wl,-rpath,{}",
            framework_dir.display()
        );
        println!(
            "cargo:rustc-link-arg=-F{}",
            framework_dir.display()
        );
        println!("cargo:rustc-link-arg=-framework");
        println!("cargo:rustc-link-arg=Chromium Embedded Framework");
    }

    #[cfg(target_os = "windows")]
    {
        let lib_dir = cef_root.join("Release");
        println!("cargo:rustc-link-search=native={}", lib_dir.display());
        println!("cargo:rustc-link-lib=dylib=libcef");
    }

    // ── Widevine CDM path ─────────────────────────────────────────────────────
    // Emit a compile-time env-var; Rust code reads it via env!().
    // Users must supply the CDM from their browser installation.
    //
    // Linux  : /usr/lib/chromium-browser/WidevineCdm/_platform_specific/linux_x64/libwidevinecdm.so
    // macOS  : ~/Library/Application Support/Google/Chrome/WidevineCdm/.../_platform_specific/mac_x64/libwidevinecdm.dylib
    // Windows: %LOCALAPPDATA%\Google\Chrome\User Data\WidevineCdm\...\widevinecdm.dll

    let widevine_path_override = env::var("WIDEVINE_CDM_PATH").ok();

    let default_widevine: Option<&str> = {
        #[cfg(target_os = "linux")]
        { Some("/usr/lib/chromium-browser/WidevineCdm/_platform_specific/linux_x64/libwidevinecdm.so") }

        #[cfg(target_os = "macos")]
        { None }   // resolved at runtime from $HOME

        #[cfg(target_os = "windows")]
        { None }   // resolved at runtime from %LOCALAPPDATA%

        #[cfg(not(any(target_os = "linux", target_os = "macos", target_os = "windows")))]
        { None }
    };

    let widevine_path = widevine_path_override
        .or_else(|| default_widevine.map(String::from))
        .unwrap_or_default();

    println!("cargo:rustc-env=WIDEVINE_CDM_PATH_DEFAULT={widevine_path}");
    println!("cargo:rerun-if-env-changed=CEF_ROOT");
    println!("cargo:rerun-if-env-changed=WIDEVINE_CDM_PATH");
}
