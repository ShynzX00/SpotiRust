// src/main.rs
//
// Spoti-Rust – lightweight cross-platform Spotify desktop client.
//
// Architecture
// ────────────────────────────────────────────────────────────────────────────
//
//   ┌─────────────────────────────────────────────────────────────────────┐
//   │  CEF (hidden Chromium window)                                        │
//   │    open.spotify.com  +  bridge.js                                   │
//   │         │  JS → Rust IPC (cefQuery / ProcessMessage)                 │
//   │         ▼                                                            │
//   │  BrowserHandler  ──writes──▶  Arc<Mutex<PlayerState>>               │
//   │         │                           │                                │
//   │         │                           ├──▶  souvlaki (OS media keys)   │
//   │         │                           └──▶  TODO: UI window hook       │
//   │         │                                                            │
//   │  CommandSink  ◀──JS eval──  media keys / tray / UI buttons          │
//   └─────────────────────────────────────────────────────────────────────┘
//
// Thread model
// ─────────────────────────────────────────────────────────────────────────────
//   • Main thread  : CEF message loop + tray event polling
//   • CEF IO thread: handled internally by libcef
//   • Tokio runtime: not used in this scaffold but wired for future async IPC

mod cef;
mod controls;
mod ipc;
mod player;
mod tray;
mod widevine;

use std::sync::Arc;
use tracing::info;
use tracing_subscriber::EnvFilter;

use player::{new_shared_state, CommandSink, SharedState};
use ipc::JsCommand;

// ── CommandSink implementation backed by a live CEF Browser ──────────────────

struct CefCommandSink {
    // We store the browser behind a Mutex so the sink can be shared safely.
    browser: parking_lot::Mutex<Option<cef_rs::Browser>>,
}

impl CefCommandSink {
    fn new() -> Arc<Self> {
        Arc::new(Self { browser: parking_lot::Mutex::new(None) })
    }

    fn set_browser(&self, b: cef_rs::Browser) {
        *self.browser.lock() = Some(b);
    }
}

impl CommandSink for CefCommandSink {
    fn send(&self, cmd: JsCommand) {
        if let Some(browser) = self.browser.lock().as_ref() {
            cef::exec_command(browser, cmd);
        } else {
            tracing::warn!("CommandSink: browser not ready, dropping {cmd:?}");
        }
    }
}

// ── Entry point ───────────────────────────────────────────────────────────────

fn main() {
    // ── Logging ───────────────────────────────────────────────────────────────
    tracing_subscriber::fmt()
        .with_env_filter(
            EnvFilter::try_from_default_env()
                .unwrap_or_else(|_| EnvFilter::new("info")),
        )
        .init();

    info!("spoti-rust starting");

    // ── Shared state ──────────────────────────────────────────────────────────
    let state: SharedState = new_shared_state();

    // ── CEF subprocess check ──────────────────────────────────────────────────
    // CEF spawns renderer/GPU sub-processes that re-execute this binary.
    // They must be handed off before any app-level init.
    let exit_code = cef::execute_process();
    if exit_code >= 0 {
        std::process::exit(exit_code);
    }

    // ── CEF init ──────────────────────────────────────────────────────────────
    let cef_settings = cef::build_cef_settings();
    cef::initialize(&cef_settings, SpotiApp)
        .expect("CEF init failed");

    // ── Command sink ──────────────────────────────────────────────────────────
    let sink = CefCommandSink::new();
    let sink_dyn: Arc<dyn CommandSink> = Arc::clone(&sink) as Arc<dyn CommandSink>;

    // ── OS media controls ─────────────────────────────────────────────────────
    let mut media_controls = controls::init_media_controls(
        Arc::clone(&state),
        Arc::clone(&sink_dyn),
    ).expect("Failed to initialise OS media controls");

    // ── System tray ───────────────────────────────────────────────────────────
    let tray = tray::TrayManager::new(
        Arc::clone(&state),
        Arc::clone(&sink_dyn),
    );

    // ── CEF browser ───────────────────────────────────────────────────────────
    let handler = cef::BrowserHandler::new(
        Arc::clone(&state),
        Arc::clone(&sink_dyn),
    );
    let browser = cef::create_browser(handler);
    sink.set_browser(browser);

    // ── TODO: UI window hook ──────────────────────────────────────────────────
    // Create your lightweight native UI window here (e.g. winit + wgpu, or
    // a simple Win32/Cocoa/GTK window).  Pass `Arc::clone(&state)` for reads
    // and `Arc::clone(&sink_dyn)` to dispatch play/pause/seek button presses.
    //
    // Example skeleton:
    //
    //   let ui = ui::Window::new(Arc::clone(&state), Arc::clone(&sink_dyn));
    //   ui.show();
    //
    // The UI window should:
    //   • Subscribe to state changes (via a tokio channel or polling).
    //   • Call `sink_dyn.send(JsCommand::TogglePlay)` on button press.
    //   • On close: hide itself instead of calling std::process::exit().
    // ─────────────────────────────────────────────────────────────────────────

    info!("Entering main event loop");

    // ── Main event loop ───────────────────────────────────────────────────────
    // CEF requires its message loop to run on the main thread.
    // We interleave tray polling and state-metadata pushes here.

    loop {
        // Run one iteration of the CEF message loop.
        cef::do_message_loop_work();

        // Drain tray / menu events.
        tray.poll();

        // Push updated metadata to the OS Now Playing / MPRIS / SMTC bar.
        controls::update_metadata(&mut media_controls, &state);

        // TODO: UI window hook – tick the UI event loop here if needed,
        //       e.g. `ui.poll_events()`.

        // Yield to avoid 100 % CPU on the main thread.
        std::thread::sleep(std::time::Duration::from_millis(16));
    }

    // `cef::shutdown()` is called via a Drop guard registered during `cef::initialize`.
}
