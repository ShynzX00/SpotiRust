// src/widevine.rs
//
// Resolves the Widevine CDM library path at runtime.
//
// Search order:
//   1. WIDEVINE_CDM_PATH env-var  (always wins if set)
//   2. Compile-time default baked in by build.rs
//   3. Platform-specific well-known locations (searched in order)
//
// The returned path is NOT validated to exist here; callers may log a warning
// if the path is absent.

use std::{env, path::PathBuf};

/// Returns the first Widevine CDM path that exists on disk, or `None`.
pub fn widevine_cdm_path() -> Option<PathBuf> {
    // 1. Runtime override.
    if let Ok(p) = env::var("WIDEVINE_CDM_PATH") {
        let path = PathBuf::from(p);
        if path.exists() { return Some(path); }
    }

    // 2. Compile-time default (set by build.rs).
    let compile_default = env!("WIDEVINE_CDM_PATH_DEFAULT");
    if !compile_default.is_empty() {
        let path = PathBuf::from(compile_default);
        if path.exists() { return Some(path); }
    }

    // 3. Platform-specific search.
    for candidate in platform_candidates() {
        if candidate.exists() {
            return Some(candidate);
        }
    }

    None
}

// ── Platform candidates ───────────────────────────────────────────────────────

#[cfg(target_os = "linux")]
fn platform_candidates() -> Vec<PathBuf> {
    // Common Linux locations for Widevine (Chromium, Chrome, Brave, etc.)
    vec![
        PathBuf::from(
            "/usr/lib/chromium-browser/WidevineCdm/_platform_specific/linux_x64/libwidevinecdm.so",
        ),
        PathBuf::from(
            "/usr/lib/chromium/WidevineCdm/_platform_specific/linux_x64/libwidevinecdm.so",
        ),
        PathBuf::from(
            "/opt/google/chrome/WidevineCdm/_platform_specific/linux_x64/libwidevinecdm.so",
        ),
        PathBuf::from(
            "/usr/lib/x86_64-linux-gnu/chromium-browser/libwidevinecdm.so",
        ),
        // Brave browser
        PathBuf::from(
            "/opt/brave.com/brave/WidevineCdm/_platform_specific/linux_x64/libwidevinecdm.so",
        ),
    ]
}

#[cfg(target_os = "macos")]
fn platform_candidates() -> Vec<PathBuf> {
    // macOS: Widevine lives in the Chrome user-data directory.
    // The version directory is dynamic; we glob the most common locations.
    let home = dirs::home_dir().unwrap_or_default();

    let bases: Vec<PathBuf> = vec![
        // Google Chrome (stable)
        home.join("Library/Application Support/Google/Chrome/WidevineCdm"),
        // Google Chrome Canary
        home.join("Library/Application Support/Google/Chrome Canary/WidevineCdm"),
        // Chromium
        home.join("Library/Application Support/Chromium/WidevineCdm"),
    ];

    // Flatten: for each base, try to find the first versioned sub-path.
    bases.into_iter().flat_map(|base| {
        glob_widevine_macos(base)
    }).collect()
}

#[cfg(target_os = "macos")]
fn glob_widevine_macos(base: PathBuf) -> Vec<PathBuf> {
    // Structure: <base>/<version>/_platform_specific/mac_x64/libwidevinecdm.dylib
    let Ok(entries) = std::fs::read_dir(&base) else { return vec![]; };
    entries
        .filter_map(|e| e.ok())
        .map(|e| {
            e.path()
             .join("_platform_specific/mac_x64/libwidevinecdm.dylib")
        })
        .filter(|p| p.exists())
        .collect()
}

#[cfg(target_os = "windows")]
fn platform_candidates() -> Vec<PathBuf> {
    let local_app_data = dirs::data_local_dir().unwrap_or_default();

    vec![
        // Google Chrome
        local_app_data.join(
            r"Google\Chrome\User Data\WidevineCdm\_platform_specific\win_x64\widevinecdm.dll",
        ),
        // Microsoft Edge (also ships Widevine)
        local_app_data.join(
            r"Microsoft\Edge\User Data\WidevineCdm\_platform_specific\win_x64\widevinecdm.dll",
        ),
        // Brave
        local_app_data.join(
            r"BraveSoftware\Brave-Browser\User Data\WidevineCdm\_platform_specific\win_x64\widevinecdm.dll",
        ),
    ]
}

// Fallback for unsupported platforms (e.g., FreeBSD builds).
#[cfg(not(any(target_os = "linux", target_os = "macos", target_os = "windows")))]
fn platform_candidates() -> Vec<PathBuf> {
    vec![]
}
