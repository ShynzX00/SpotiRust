// src/controls/mod.rs
//
// Native OS media-key integration via `souvlaki`.
//
//   Linux   → MPRIS2 D-Bus interface (requires the `mpris` feature flag)
//   macOS   → Now Playing / NowPlayingCenter
//   Windows → System Media Transport Controls (SMTC)
//
// When a hardware media key fires, souvlaki calls our `MediaControlEvent`
// handler, which translates the event into a `JsCommand` and forwards it
// to CEF through the shared `CommandSink`.

use std::sync::Arc;
use souvlaki::{
    MediaControls, MediaControlEvent, MediaMetadata, MediaPlayback, PlatformConfig,
};
use tracing::{info, error};

use crate::{
    ipc::JsCommand,
    player::{SharedState, CommandSink},
};

/// Initialises OS media controls and returns the live `MediaControls` handle.
///
/// **Keep the handle alive** for as long as the app runs; dropping it
/// deregisters the media session.
pub fn init_media_controls(
    state:        SharedState,
    command_sink: Arc<dyn CommandSink>,
) -> Result<MediaControls, souvlaki::Error> {

    // ── Platform configuration ────────────────────────────────────────────────
    let config = platform_config();

    let mut controls = MediaControls::new(config)?;

    // ── Event handler: media keys → JsCommand ─────────────────────────────────
    let sink = Arc::clone(&command_sink);
    controls.attach(move |event: MediaControlEvent| {
        info!("Media key event: {event:?}");
        let cmd = match event {
            MediaControlEvent::Play | MediaControlEvent::Pause
            | MediaControlEvent::Toggle    => Some(JsCommand::TogglePlay),
            MediaControlEvent::Next        => Some(JsCommand::Next),
            MediaControlEvent::Previous    => Some(JsCommand::Prev),
            MediaControlEvent::Seek(pos)   => {
                // souvlaki gives us an absolute SeekDirection; convert to fraction.
                // For simplicity we nudge by 10 s.
                use souvlaki::SeekDirection;
                let _ = pos; // consumed below via match arm
                None          // handled separately below
            }
            MediaControlEvent::SeekBy(dir, duration) => {
                use souvlaki::SeekDirection;
                // We'd need current state to compute accurate fraction; skip for now.
                info!("SeekBy {dir:?} {duration:?} – ignored (requires state)");
                None
            }
            MediaControlEvent::Stop => {
                // Spotify web player has no explicit stop; treat as pause.
                Some(JsCommand::TogglePlay)
            }
            _ => None,
        };

        if let Some(c) = cmd {
            sink.send(c);
        }
    })?;

    // ── Set initial metadata ───────────────────────────────────────────────────
    update_metadata(&mut controls, &state);

    Ok(controls)
}

/// Call this whenever `PlayerState` is updated to push fresh metadata to the OS.
pub fn update_metadata(controls: &mut MediaControls, state: &SharedState) {
    let s = state.lock();

    let playback = if s.is_playing() {
        MediaPlayback::Playing { progress: None }
    } else {
        MediaPlayback::Paused  { progress: None }
    };

    if let Err(e) = controls.set_playback(playback) {
        error!("Failed to set OS playback state: {e}");
    }

    let meta = MediaMetadata {
        title:  Some(s.title()),
        artist: Some(s.artist()),
        // album_art_url is a remote URL; souvlaki accepts it on some platforms.
        cover_url: s.current.as_ref().map(|c| c.album_art_url.as_str()),
        ..Default::default()
    };

    if let Err(e) = controls.set_metadata(meta) {
        error!("Failed to set OS metadata: {e}");
    }
}

// ── Platform configuration ────────────────────────────────────────────────────

#[cfg(target_os = "linux")]
fn platform_config() -> PlatformConfig {
    PlatformConfig {
        dbus_name:    "spoti-rust",
        display_name: "Spoti-Rust",
        hwnd: None,
    }
}

#[cfg(target_os = "macos")]
fn platform_config() -> PlatformConfig {
    PlatformConfig {
        // macOS Now Playing uses the app's bundle name automatically.
        dbus_name:    "spoti-rust",
        display_name: "Spoti-Rust",
        hwnd: None,
    }
}

#[cfg(target_os = "windows")]
fn platform_config() -> PlatformConfig {
    // On Windows we need the HWND of any visible window.
    // Filled in after the UI window is created.
    // TODO: UI window hook – replace `None` with the real HWND.
    PlatformConfig {
        dbus_name:    "spoti-rust",
        display_name: "Spoti-Rust",
        hwnd: None,
    }
}

#[cfg(not(any(target_os = "linux", target_os = "macos", target_os = "windows")))]
fn platform_config() -> PlatformConfig {
    PlatformConfig {
        dbus_name:    "spoti-rust",
        display_name: "Spoti-Rust",
        hwnd: None,
    }
}
