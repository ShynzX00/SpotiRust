// src/player/mod.rs
//
// Thread-safe player state shared between:
//   • The CEF message handler  (writes)
//   • The souvlaki media-key handler  (reads + issues JS commands)
//   • The UI window hook  (reads for display)

use std::sync::Arc;
use parking_lot::Mutex;
use crate::ipc::{StateUpdate, JsCommand};

// ── State ─────────────────────────────────────────────────────────────────────

#[derive(Debug, Clone, Default)]
pub struct PlayerState {
    /// Last `STATE_UPDATE` received from the bridge. `None` before first event.
    pub current: Option<StateUpdate>,
    /// Whether the bridge has confirmed authentication.
    pub authenticated: bool,
}

/// Alias used throughout the crate.
pub type SharedState = Arc<Mutex<PlayerState>>;

pub fn new_shared_state() -> SharedState {
    Arc::new(Mutex::new(PlayerState::default()))
}

// ── Command sink ──────────────────────────────────────────────────────────────
// A thin wrapper so the controls and tray modules don't depend directly on CEF.

/// Anything that can receive a `JsCommand` and forward it to the CEF frame.
pub trait CommandSink: Send + Sync + 'static {
    fn send(&self, cmd: JsCommand);
}

// ── Helpers ───────────────────────────────────────────────────────────────────

impl PlayerState {
    /// Convenience: return current track title or a placeholder.
    pub fn title(&self) -> &str {
        self.current
            .as_ref()
            .map(|s| s.title.as_str())
            .unwrap_or("Not playing")
    }

    pub fn artist(&self) -> &str {
        self.current
            .as_ref()
            .map(|s| s.artist.as_str())
            .unwrap_or("")
    }

    pub fn is_playing(&self) -> bool {
        self.current.as_ref().map(|s| s.is_playing).unwrap_or(false)
    }

    /// Progress as a fraction in [0.0, 1.0].
    pub fn progress_fraction(&self) -> f64 {
        self.current.as_ref().map(|s| {
            if s.duration_ms == 0 { 0.0 }
            else { s.progress_ms as f64 / s.duration_ms as f64 }
        }).unwrap_or(0.0)
    }
}
