// src/tray/mod.rs
//
// System tray icon via `tray-icon`.
//
// Behaviour
// ─────────────────────────────────────────────────────────────────────────────
// • Closing the UI window does NOT quit the process; audio keeps playing.
// • The tray icon provides a right-click menu: Show, Play/Pause, Next, Quit.
// • Left-clicking the icon shows the UI window (if any).
//
// The tray event loop runs on the main OS thread (required by tray-icon on
// all three platforms).  It forwards commands through the shared `CommandSink`.

use std::sync::Arc;
use tray_icon::{
    menu::{Menu, MenuEvent, MenuItem, PredefinedMenuItem},
    TrayIcon, TrayIconBuilder, TrayIconEvent,
};
use tracing::{info, error};

use crate::{
    ipc::JsCommand,
    player::{SharedState, CommandSink},
};

// ── Menu item IDs ─────────────────────────────────────────────────────────────

const ID_SHOW:       &str = "show";
const ID_PLAY_PAUSE: &str = "play_pause";
const ID_NEXT:       &str = "next";
const ID_PREV:       &str = "prev";
const ID_QUIT:       &str = "quit";

// ── TrayManager ───────────────────────────────────────────────────────────────

pub struct TrayManager {
    _icon:  TrayIcon,
    _state: SharedState,
    sink:   Arc<dyn CommandSink>,
}

impl TrayManager {
    /// Build and register the tray icon.  Must be called on the main thread.
    pub fn new(state: SharedState, sink: Arc<dyn CommandSink>) -> Self {
        let menu = build_menu();
        let icon = build_icon();

        let tray = TrayIconBuilder::new()
            .with_menu(Box::new(menu))
            .with_tooltip("Spoti-Rust")
            .with_icon(icon)
            .build()
            .expect("Failed to create tray icon");

        Self { _icon: tray, _state: state, sink }
    }

    /// Call this in the main event loop on each iteration to drain tray events.
    pub fn poll(&self) {
        // ── Menu events ───────────────────────────────────────────────────────
        while let Ok(event) = MenuEvent::receiver().try_recv() {
            info!("Tray menu: {:?}", event.id);
            match event.id.0.as_str() {
                ID_PLAY_PAUSE => self.sink.send(JsCommand::TogglePlay),
                ID_NEXT       => self.sink.send(JsCommand::Next),
                ID_PREV       => self.sink.send(JsCommand::Prev),
                ID_SHOW       => {
                    // TODO: UI window hook – bring the UI window to front.
                    info!("Show window requested from tray");
                }
                ID_QUIT => {
                    info!("Quit requested from tray");
                    std::process::exit(0);
                }
                _ => {}
            }
        }

        // ── Tray icon click events ────────────────────────────────────────────
        while let Ok(event) = TrayIconEvent::receiver().try_recv() {
            use tray_icon::ClickType;
            if matches!(event.click_type, ClickType::Left) {
                // TODO: UI window hook – toggle UI window visibility.
                info!("Tray left-click: toggle UI");
            }
        }
    }
}

// ── Helpers ───────────────────────────────────────────────────────────────────

fn build_menu() -> Menu {
    let menu = Menu::new();

    menu.append(&MenuItem::with_id(ID_SHOW,       "Show",       true, None)).ok();
    menu.append(&PredefinedMenuItem::separator()).ok();
    menu.append(&MenuItem::with_id(ID_PREV,       "⏮  Previous", true, None)).ok();
    menu.append(&MenuItem::with_id(ID_PLAY_PAUSE, "⏯  Play / Pause", true, None)).ok();
    menu.append(&MenuItem::with_id(ID_NEXT,       "⏭  Next",    true, None)).ok();
    menu.append(&PredefinedMenuItem::separator()).ok();
    menu.append(&MenuItem::with_id(ID_QUIT,       "Quit",       true, None)).ok();

    menu
}

fn build_icon() -> tray_icon::Icon {
    // Embed a minimal 32×32 RGBA icon at compile time.
    // Replace `assets/tray_icon.png` with your real icon.
    let (icon_rgba, icon_width, icon_height) = {
        let bytes = include_bytes!("../../assets/tray_icon.png");
        let image = image::load_from_memory(bytes)
            .expect("Invalid tray icon PNG")
            .into_rgba8();
        let (w, h) = image.dimensions();
        (image.into_raw(), w, h)
    };

    tray_icon::Icon::from_rgba(icon_rgba, icon_width, icon_height)
        .expect("Failed to build tray icon")
}
