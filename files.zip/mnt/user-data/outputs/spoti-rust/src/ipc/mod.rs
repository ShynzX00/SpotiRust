// src/ipc/mod.rs
//
// Strongly-typed representations of every message defined in the IPC contract.
//
//   JS → Rust  :  InboundMessage  (STATE_UPDATE | PLAYER_READY)
//   Rust → JS  :  JsCommand       (togglePlay | next | prev | seek | setVolume)

use serde::{Deserialize, Serialize};

// ── JS → Rust payloads ────────────────────────────────────────────────────────

/// Top-level envelope.  The `type` field drives deserialization.
#[derive(Debug, Deserialize)]
#[serde(tag = "type", rename_all = "SCREAMING_SNAKE_CASE")]
pub enum InboundMessage {
    StateUpdate(StateUpdate),
    PlayerReady(PlayerReady),
}

/// Sent by the bridge whenever Spotify's player state changes.
#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct StateUpdate {
    pub title:         String,
    pub artist:        String,
    pub album_art_url: String,
    pub is_playing:    bool,
    pub progress_ms:   u64,
    pub duration_ms:   u64,
    pub is_ad:         bool,
}

/// Sent once after the bridge script loads and Spotify's auth state is known.
#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct PlayerReady {
    pub authenticated: bool,
}

// ── Rust → JS commands ────────────────────────────────────────────────────────

/// Every command the Rust side can inject into the CEF frame.
#[derive(Debug, Clone)]
pub enum JsCommand {
    TogglePlay,
    Next,
    Prev,
    /// `percent` in [0.0, 1.0]
    Seek(f64),
    /// `percent` in [0.0, 1.0]
    SetVolume(f64),
}

impl JsCommand {
    /// Render the command as the exact JS expression from the IPC contract.
    pub fn to_js(&self) -> String {
        match self {
            JsCommand::TogglePlay       => "window.__SPOTI_RUST__.togglePlay()".into(),
            JsCommand::Next             => "window.__SPOTI_RUST__.next()".into(),
            JsCommand::Prev             => "window.__SPOTI_RUST__.prev()".into(),
            JsCommand::Seek(p)          => format!("window.__SPOTI_RUST__.seek({p})"),
            JsCommand::SetVolume(p)     => format!("window.__SPOTI_RUST__.setVolume({p})"),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn deserialize_state_update() {
        let json = r#"{
            "type": "STATE_UPDATE",
            "title": "Bohemian Rhapsody",
            "artist": "Queen",
            "album_art_url": "https://example.com/art.jpg",
            "is_playing": true,
            "progress_ms": 12000,
            "duration_ms": 354000,
            "is_ad": false
        }"#;
        let msg: InboundMessage = serde_json::from_str(json).unwrap();
        assert!(matches!(msg, InboundMessage::StateUpdate(_)));
    }

    #[test]
    fn deserialize_player_ready() {
        let json = r#"{"type":"PLAYER_READY","authenticated":true}"#;
        let msg: InboundMessage = serde_json::from_str(json).unwrap();
        assert!(matches!(msg, InboundMessage::PlayerReady(_)));
    }

    #[test]
    fn js_command_seek_format() {
        assert_eq!(
            JsCommand::Seek(0.42).to_js(),
            "window.__SPOTI_RUST__.seek(0.42)"
        );
    }
}
