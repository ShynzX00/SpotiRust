/**
 * bridge.js
 * ─────────────────────────────────────────────────────────────────────────────
 * Injected by Rust into every main frame on open.spotify.com.
 *
 * Responsibilities
 * ─────────────────
 * 1. Expose `window.__SPOTI_RUST__` with the Rust-to-JS command API.
 * 2. Poll Spotify's internal React/Redux store for player state changes and
 *    post STATE_UPDATE messages back to Rust via the CEF process-message pipe.
 * 3. Fire PLAYER_READY once Spotify's auth state is known.
 *
 * CEF IPC mechanism
 * ─────────────────
 * `cefQuery` (registered in the renderer process) is the standard
 * cef-rs / CefSharp way to send a string from JS → Rust.
 * We serialise every payload as JSON and call `window.cefQuery(...)`.
 */

(function () {
    'use strict';

    // Guard: only inject once per frame.
    if (window.__SPOTI_RUST__INJECTED__) return;
    window.__SPOTI_RUST__INJECTED__ = true;

    // ── IPC helper ────────────────────────────────────────────────────────────

    /**
     * Send a JSON payload to the Rust side.
     * `window.cefQuery` is registered by cef-rs in the renderer process.
     */
    function sendToRust(payload) {
        const json = JSON.stringify(payload);
        if (typeof window.cefQuery === 'function') {
            window.cefQuery({ request: json, persistent: false,
                              onSuccess: () => {}, onFailure: () => {} });
        } else {
            // Fallback: post via custom scheme handler if cefQuery not ready.
            console.debug('[spoti-rust bridge] cefQuery unavailable – queued:', json);
        }
    }

    // ── Rust → JS command surface  (window.__SPOTI_RUST__) ───────────────────

    /**
     * Returns Spotify's internal Cosmos API endpoint (varies by version).
     * We access the React Fiber root to reach the Redux store.
     */
    function getSpotifyPlayer() {
        // Try the global registry that newer Spotify web app versions expose.
        return window.Spicetify?.Player || window.__spotify_web_player__;
    }

    window.__SPOTI_RUST__ = {
        togglePlay() {
            Spicetify?.Player?.togglePlay?.() ??
            document.querySelector('[data-testid="control-button-playpause"]')?.click();
        },
        next() {
            Spicetify?.Player?.next?.() ??
            document.querySelector('[data-testid="control-button-skip-forward"]')?.click();
        },
        prev() {
            Spicetify?.Player?.back?.() ??
            document.querySelector('[data-testid="control-button-skip-back"]')?.click();
        },
        /**
         * @param {number} percent – value in [0, 1]
         */
        seek(percent) {
            const player = getSpotifyPlayer();
            if (player?.getDuration) {
                const ms = Math.round(player.getDuration() * percent);
                player.seek(ms);
            }
        },
        /**
         * @param {number} percent – value in [0, 1]
         */
        setVolume(percent) {
            Spicetify?.Player?.setVolume?.(percent);
        },
    };

    // ── State polling ─────────────────────────────────────────────────────────

    let lastTitle = null;
    let lastPlaying = null;

    function pollState() {
        try {
            const data = Spicetify?.Player?.data;
            if (!data) return;

            const title      = data.item?.name       ?? '';
            const artist     = data.item?.artists?.map(a => a.name).join(', ') ?? '';
            const artUrl     = data.item?.album?.images?.[0]?.url ?? '';
            const isPlaying  = data.is_playing ?? false;
            const progressMs = data.position ?? 0;
            const durationMs = data.item?.duration?.milliseconds ?? 0;
            const isAd       = data.item?.type === 'ad';

            // Only fire if something meaningful changed.
            if (title !== lastTitle || isPlaying !== lastPlaying) {
                lastTitle   = title;
                lastPlaying = isPlaying;

                sendToRust({
                    type:          'STATE_UPDATE',
                    title,
                    artist,
                    album_art_url: artUrl,
                    is_playing:    isPlaying,
                    progress_ms:   progressMs,
                    duration_ms:   durationMs,
                    is_ad:         isAd,
                });
            }
        } catch (e) {
            // Swallow – Spotify may not be ready yet.
        }
    }

    // Poll every 500 ms.  Replace with an event listener if Spicetify exposes one.
    setInterval(pollState, 500);

    // ── PLAYER_READY ──────────────────────────────────────────────────────────

    function checkAuth() {
        // `Spicetify.User` is populated once the web app bootstraps.
        const user = window.Spicetify?.User;
        if (user) {
            sendToRust({
                type:          'PLAYER_READY',
                authenticated: !!user.username,
            });
            return true;
        }
        return false;
    }

    // Retry until Spotify's internals are ready (up to ~10 s).
    let authRetries = 0;
    const authInterval = setInterval(() => {
        if (checkAuth() || ++authRetries > 20) {
            clearInterval(authInterval);
        }
    }, 500);

    console.info('[spoti-rust bridge] injected ✓');
})();
